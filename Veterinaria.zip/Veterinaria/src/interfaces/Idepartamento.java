/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package interfaces;

import javax.swing.JComboBox;
import modelo.departamento;
import java.util.*;
/**
 *
 * @author Esteban
 */
public interface Idepartamento {

   
    
    

  
}
