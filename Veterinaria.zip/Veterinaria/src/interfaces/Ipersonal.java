/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package interfaces;

import modelo.personal;
import java.util.*;
import modelo.cliente;

public interface Ipersonal {


personal login (String nombre, String pass);
 void adicion (personal ep);
    
}
